package com.r462.hammad.questionnaire;

import android.app.Activity;
import android.Manifest.permission;
import android.content.pm.PackageManager;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.r462.hammad.questionnaire.DAL.ManageQuestionnaireDAL;
import com.r462.hammad.questionnaire.DAL.SharedPreferences;
import com.r462.hammad.questionnaire.showonMap.OnDataMap;
import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabReselectListener;
import com.roughike.bottombar.OnTabSelectListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import layout.Victim;
import layout.crimeArea;
import layout.crimeDate;
import layout.crimeTime;
import layout.criminalFacialFeature;
import layout.criminalOutfit;
import layout.criminalVehicle;
import layout.criminalVehicleIdentification;
import layout.criminialWeapon;
import layout.numbersOfcrimnal;
import layout.reportView;
import layout.treatmentByCriminal;
import layout.typeOfCrime;


public class MainActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener {


    FirebaseDatabase firebase;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference();

    ArrayList<String> AnyIdentiferKey = null;
    ArrayList<String> casualties = null;
    ArrayList<String> crimeDate = null;
    private ArrayList<String> crimeLocation = null;
    int count;
    //new ArrayList<String>();
    ArrayList<String> crimeTime = null;
    ArrayList<String> crimeVictim = null;
    ArrayList<String> crimeVehicle = null;
    ArrayList<String> MobileSnatchingRelated = null;
    ArrayList<String> noOfCriminal = null;
    ArrayList<String> typeOfCriminal = null;
    ArrayList<String> vehicleSnatchingRelated = null;
    ArrayList<String> typeOfWeapon = null;
    ArrayList<String> facialFeaturecriminal = null;
    ArrayList<String> treatByCriminal = null;
    ArrayList<String> identificationOfVehicle = null;
    ArrayList<String> ArrLocation;
    String Lat = "67.0689859";
    String Long = "67.0689859";


    // Teli App
    String[] permissionsRequired = new String[]{android.Manifest.permission.INTERNET,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION};
    private SharedPreferences permissionStatus;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private boolean sentToSettings = false;
    //


    public static int SPLASH_TIME_OUT = 4000;
    public static int REMOVE_VALUE = 0;
    public static int TYPE_OF_CRIME = 0;
    public static int VICTIM = 0;
    /* firebase initialization*/


    String crimeType = "";
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    GoogleApiClient mgoogleApiclient;
    LocationRequest mlocationRequest;
    Marker mCurrLocationMarker;
    Location loc;
    Marker marker;
    PolygonOptions mPolygon;
    String Latitude = "67.0689859";
    String Longitde = "67.0689859";


    PlaceAutocompleteFragment placeAutoComplete;

    GoogleMap mMap;
    GoogleApiClient mGoogleApiClient;
    Location mLastlocation;
    LocationRequest mLocationRequest;
    private static final String TAG = "MainActivity";
    View mapView;
    public static ArrayList<String> genericArray = new ArrayList<String>();

    Victim victim;
    typeOfCrime typeofcrime;
    public static int UNIQUE_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mPolygon = new PolygonOptions();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int permissionCheck = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_APN_SETTINGS);


        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            //requesting permission
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_APN_SETTINGS}, 1);
        } else {
            //permission is granted and you can change APN settings
        }

        database.keepSynced(true);

        intiMap();


        final SearchView searchView = (SearchView) findViewById(R.id.searchView);


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                try {
                    search(query);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // search(newText);
                return false;
            }
        });


        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        //getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new reportView()).commit();


        // recent bottomnavigation View//

       BottomNavigationView bottomNavigationView;
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();
                switch (id) {
                    case R.id.home_Screen:
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    case R.id.report_crime:
                        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, new typeOfCrime()).commit();
                }


                return false;


            }
        });


    }


    private void search(String location) throws IOException {
        Geocoder geocoder = new Geocoder(this);

        List<Address> list = geocoder.getFromLocationName(location, 1);
        if (location == null) {


            //if the search bar is empty

        }
        android.location.Address address = list.get(0);
        String locality = address.getLocality();
        String country = address.getCountryName();
        Toast.makeText(this, locality, Toast.LENGTH_LONG).show();
        double lat = address.getLatitude();
        double lon = address.getLongitude();

        LatLng latLng = new LatLng(lat, lon);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(13));


    }

    private void moveCamera(LatLng latLng, float zoom, String title) {
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));


    }

    private void intiMap() {


        /*Google Map fragment*/
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapView = mapFragment.getView();
        mapFragment.getMapAsync(this);

        dataOnMAp();

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        //  mLocationRequest.setInterval(1000);
        // mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        mLastlocation = location;
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(13));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);


        if (mapView != null &&
                mapView.findViewById(Integer.parseInt("1")) != null) {
            // Get the button view
            View locationButton = ((View) mapView.findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
            // and next place it, on bottom right (as Google Maps app)
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)
                    locationButton.getLayoutParams();
            // position on right bottom
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
            layoutParams.setMargins(0, 180, 180, 30);
        }
        try {
            // Customise the styling of the base map using a JSON object defined
              // in a raw resource file.
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.style_json));

            if (!success) {
                Log.e(TAG, "Style parsing failed.");
            }
        } catch (Resources.NotFoundException e) {
            Log.e(TAG, "Can't find style. Error: ", e);
        }
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        buildGoogleApiClient();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Questionnaires");


        Toast.makeText(getApplication(), "" + reference.toString(), Toast.LENGTH_LONG).show();

    }

    protected synchronized void buildGoogleApiClient() {

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();

        //OnDataMap onDataMap = new OnDataMap();



    }

    public void dataOnMAp() {


        database.child("Questionnaires").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


                //stop progress bar here


                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    AnyIdentiferKey = (ArrayList<String>) dataSnapshot1.child("Any Identification of Vehicle").getValue();
                    casualties = (ArrayList<String>) dataSnapshot1.child("Casualties").getValue();
                    crimeDate = (ArrayList<String>) dataSnapshot1.child("Crime Date").getValue();
                    crimeLocation = (ArrayList<String>) dataSnapshot1.child("Crime Location").getValue();
                    typeOfCriminal = (ArrayList<String>) dataSnapshot1.child("Type Of Crime").getValue();
                    noOfCriminal = (ArrayList<String>) dataSnapshot1.child("No of Criminal").getValue();
                    crimeTime = (ArrayList<String>) dataSnapshot1.child("Crime Time").getValue();



                    if (crimeLocation != null) {
                        Lat = crimeLocation.get(0).toString();
                        Long = crimeLocation.get(1).toString();
                        LatLng latLng = new LatLng(Double.valueOf(Lat), Double.valueOf(Long));
                       // if (typeOfCriminal.get(0).toString() == "Mobile snatching") {
                         //   mMap.addMarker(new MarkerOptions().position(latLng).title("crime")
                           //         .snippet("and snippet")
                            //        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
                       // } else {


                            mMap.addMarker(new MarkerOptions().position(latLng).title(typeOfCriminal.toString()).snippet("Date"+crimeDate  + "Time"+crimeTime));
                       // }


                    }
                    crimeVictim = (ArrayList<String>) dataSnapshot1.child("Crime Victim ").getValue();
                    crimeVehicle = (ArrayList<String>) dataSnapshot1.child("Criminal Vehicle").getValue();
                    MobileSnatchingRelated = (ArrayList<String>) dataSnapshot1.child("Mobile snaching Related").getValue();
                    typeOfWeapon = (ArrayList<String>) dataSnapshot1.child("Type of Weapon").getValue();
                    vehicleSnatchingRelated = (ArrayList<String>) dataSnapshot1.child("TVehicle snaching Related").getValue();
                    facialFeaturecriminal = (ArrayList<String>) dataSnapshot1.child("Facial fearure").getValue();
                    treatByCriminal = (ArrayList<String>) dataSnapshot1.child("Treatment By Criminal").getValue();
                    identificationOfVehicle = (ArrayList<String>) dataSnapshot1.child(" Any Identification of Vehicle").getValue();


                    Log.d("AnyIdenfier", "" + AnyIdentiferKey);
                    Log.d("crimeVictim", "" + crimeVictim);
                    Log.d("casualties", "" + casualties);
                    Log.d("crimeDate", "" + crimeDate);
                    Log.d("crimeLocation", "" + crimeLocation);
                    // for(int i=0;i<crimeLocation.size()-1;i++){


                    Log.d("crimeTime", "" + crimeTime);
                    Log.d("crimeVehicle", "" + crimeVehicle);
                    Log.d("MobileSnatchingRelated", "" + MobileSnatchingRelated);
                    Log.d("noCriminal", "" + noOfCriminal);
                    Log.d("typeOfCriminal", "" + typeOfCriminal);
                    Log.d("typeOfWeapon", "" + typeOfWeapon);
                    Log.d("vehicleSnatchedRelated", "" + vehicleSnatchingRelated);
                    Log.d("facialFeaturecriminal", "" + facialFeaturecriminal);
                    Log.d("treatByCriminal", "" + treatByCriminal);
                    Log.d("identificationOfVehicle", "" + identificationOfVehicle);


                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }


    public void markerOnMap(String Latitude, String Longitde) {

        if (Latitude != null && Longitde != null) {
            Double Lat = Double.valueOf(Latitude);
            Double Long = Double.valueOf(Longitde);
            //Latitude= Double.valueOf(Crime_Location.toString());
            // Longitude= Double.valueOf(Crime_Location.get(1).toString());
            // for(int i=0;i<crimeLocation.size()-1;i++){
            //  Latitude= Double.valueOf(crimeLocation.get(0).toString());
            //  Longitude= Double.valueOf(crimeLocation.get(1).toString());

            // }
            //  Toast.makeText(this,""+ crimeLocation.toString(),Toast.LENGTH_LONG).show();
            //Toast.makeText(this,""+ user.get(1).getBytes(),Toast.LENGTH_LONG).show();

            //    Double latitude = Double.valueOf(crimeLocation.get(0));
            //  Double longitute =  Double.valueOf(crimeLocation.get(1));
           // LatLng latLng = new LatLng(Lat, Long);

           // mMap.addMarker(new MarkerOptions().position(latLng).title("crime"));
        }

    }

    private void goToLocation(double lat, double lon) {

        LatLng ll = new LatLng(lat, lon);
        CameraUpdate update = CameraUpdateFactory.newLatLng(ll);
        mMap.moveCamera(update);
    }

    public void onFragmentInteraction(String Type) {

        crimeType = Type;
        Toast.makeText(this, Type, Toast.LENGTH_SHORT).show();


    }

    public void backTypeofCrimeClick(View view) {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
        // getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new reportView()).addToBackStack(null).commit();
    }

    public void backVictimClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new typeOfCrime()).addToBackStack(null).commit();
    }

    public void backCrimeAreaClick(View view) {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Victim()).addToBackStack(null).commit();
    }

    public void backCrimeTime(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new crimeArea()).addToBackStack(null).commit();
    }

    public void backCrimeDateClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new crimeTime()).addToBackStack(null).commit();

    }

    public void backNumberOfCriminalClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new crimeDate()).addToBackStack(null).commit();
    }

    public void backWeaponClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new numbersOfcrimnal()).addToBackStack(null).commit();

    }

    public void backFacialFeatureClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new criminialWeapon()).addToBackStack(null).commit();

    }

    public void backOutfitCriminalClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new criminalFacialFeature()).addToBackStack(null).commit();

    }

    public void backCriminalVehicleClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new criminalOutfit()).addToBackStack(null).commit();

    }

    public void backCriminalVehicleIdentificationClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new criminalVehicle()).addToBackStack(null).commit();
    }

    public void backTreatmentByCriminalClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new criminalVehicleIdentification()).addToBackStack(null).commit();

    }

    public void backCasualtiesByCriminalClick(View view) {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new treatmentByCriminal()).addToBackStack(null).commit();


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //premission granted by user
                } else {
                    //permission denied by user
                }
            }
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}












